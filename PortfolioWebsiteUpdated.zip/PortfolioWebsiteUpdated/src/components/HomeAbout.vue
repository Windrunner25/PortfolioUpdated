<template>
  <div style="margin-left: 20px">
    <h1>About</h1>
    <p>
      As a Computer Science major and past Microsoft 365 intern at TiER1
      Performance, I am passionate about applying my technical and interpersonal
      skills to problem-solve and adapt regardless of the situation. I am also a
      Management Fellow, Student-Athlete, Presidential Ambassador, and DePauw
      Consulting Group exec, demonstrating my leadership, teamwork, and
      problem-solving abilities in various settings and roles.
    </p>
  </div>
</template>
