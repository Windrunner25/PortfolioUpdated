<template>
  <SkillCard />
</template>

<script setup lang="ts">
import SkillCard from "./SkillCard.vue";
</script>
