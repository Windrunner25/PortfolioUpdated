<template>
    <h1>
        Skills
    </h1>
</template>