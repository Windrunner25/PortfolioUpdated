<template>
  <div
    style="
      display: flex;
      flex-direction: column;
      gap: 10px;
      align-items: flex-start;
      justify-content: center;
    "
  >
    <a href="https://www.strava.com/athletes/brianwolf" target="_blank">
      <img src="../assets/stravaimg.png" alt="strava logo" height="50px" />
    </a>

    <a href="https://www.linkedin.com/in/brian-wolf-44072021b/" target="_blank">
      <div
        style="
          display: flex;
          align-items: center;
          justify-content: center;
          width: 50px;
          height: 50px;
          overflow: hidden;
        "
      >
        <img
          src="../assets/linkedin-logo-3.png"
          alt="linkedIn logo"
          height="100%"
          width="100%"
          style="object-fit: contain"
        />
      </div>
    </a>
    <a href="https://github.com/Windrunner25" target="_blank">
      <div
        style="
          background-color: white;
          display: flex;
          align-items: center;
          justify-content: center;
          width: 50px;
        "
      >
        <img
          src="../assets/githubimg.png"
          alt="Github logo"
          height="40 px"
          width="40 px"
        />
      </div>
    </a>
  </div>
</template>
