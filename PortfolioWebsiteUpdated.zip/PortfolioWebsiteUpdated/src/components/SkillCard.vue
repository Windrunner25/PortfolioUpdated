<template>
  <v-card>
    <v-card-title>This is a title</v-card-title>
    <v-card-subtitle>This is a card subtitle</v-card-subtitle>
    <v-card-text>
      Lorem ipsum dolor sit amet consectetur adipisicing elit. Commodi, ratione
      debitis quis est labore voluptatibus!
    </v-card-text>
  </v-card>
</template>

<script>
import { defineComponent } from "vue";

export default defineComponent({
  name: "SkillCard",
});
</script>
