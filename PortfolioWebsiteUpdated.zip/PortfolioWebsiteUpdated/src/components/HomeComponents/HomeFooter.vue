<template>
  <div class="footer"><p>Add me on socials!</p></div>
</template>

<style>
.footer {
  background-color: var(--vt-c-black-soft);
  width: 100%;
  /* position: fixed; */
  top: 0;
  left: 0;
  width: 100%;
  margin: 0; /* Remove any default margins */
  padding: 50px;
}
</style>
