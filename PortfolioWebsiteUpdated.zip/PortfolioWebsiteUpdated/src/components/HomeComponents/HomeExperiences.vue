<template>
  <h1>Coding Projects</h1>
  <h3>Goodreads Sentiment Analysis</h3>
  <ul>
    <li class="bullets">
      Committed research on the significance of reading level and sentiment
      level as it relates to book recommendations
    </li>
    <li class="bullets">
      Languages and packages: python and NLTK, numpy, pandas, textstat,
      matplotlib
    </li>
  </ul>
  <br />
  <h3>Web Application for Geospatial Data Visualization</h3>
  <ul>
    <li class="bullets">
      Developed web application using React, JavaScript, and Material UI while
      shadowing a client team; implemented proper version control, code
      structure, and iterative development to produce credible demo to acquire
      new clients.
    </li>
    <li class="bullets">
      Languages, frameworks, and packages: JavaScript, Python, React, Material
      UI, jupyter notebook, geopandas, QGIS,
    </li>
  </ul>
</template>

<style scoped>
.bullets {
  margin-left: 20px;
}
</style>
