<template>
  <div>
    <h1>Projects</h1>
  </div>
</template>

<style></style>
