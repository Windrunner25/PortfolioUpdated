<template>
  <div>
    <ExperienceTop />
    <ExperienceDetails />
  </div>
</template>

<script setup lang="ts">
import ExperienceDetails from "@/components/ExperienceComponents/ExperienceDetails.vue";
import ExperienceTop from "@/components/ExperienceComponents/ExperienceTop.vue";
</script>

<style></style>
