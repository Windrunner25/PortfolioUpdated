<template>
  <div>
    <ContactForm />
  </div>
</template>

<script setup lang="ts">
import ContactForm from "@/components/ContactComponents/contactForm.vue";
</script>

<style></style>
