<template>
    <div>
      <h1>Contact</h1>
    </div>
  </template>
  
  
  <style>
  
  </style>
  